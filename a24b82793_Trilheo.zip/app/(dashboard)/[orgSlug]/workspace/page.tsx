import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/modules/auth";
import { db } from "@/lib/db";

/**
 * Workspace (Fase 1) — fora do escopo deste pacote (Fase 2/Marco 1:
 * Inovação). Página placeholder que lista workspaces da organização
 * para o link do header não ficar 404.
 */
export default async function WorkspacePage({
  params,
}: {
  params: { orgSlug: string };
}) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const workspaces = await db.workspace.findMany({
    where: { organizationId: session.user.organizationId },
    orderBy: { createdAt: "asc" },
  });

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Workspace</h1>
        <p className="text-sm text-muted-foreground">
          Gestão de workspaces (Fase 1) — fora do escopo deste pacote.
        </p>
      </div>
      <ul className="space-y-2">
        {workspaces.map((w) => (
          <li
            key={w.id}
            className="rounded-md border border-border bg-background px-4 py-3 text-sm"
          >
            {w.name}
          </li>
        ))}
        {workspaces.length === 0 && (
          <li className="rounded-md border border-dashed border-border px-4 py-8 text-center text-sm text-muted-foreground">
            Nenhum workspace.
          </li>
        )}
      </ul>
    </div>
  );
}

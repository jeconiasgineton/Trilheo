"use client";

import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  createIdeaAction,
  updateIdeaAction,
} from "@/lib/modules/innovation/actions";
import type { IdeaItem, StageColumn } from "./idea-kanban";

/**
 * Modal de criar/editar ideia. No criar, o estágio é opcional (default
 * = primeiro estágio do pipeline do board). Mover entre estágios é
 * feito pelo Kanban (drag & drop), não por este dialog.
 */
export function IdeaDialog({
  boardId,
  columns,
  idea,
  onClose,
  onSaved,
}: {
  boardId: string;
  columns: StageColumn[];
  idea: IdeaItem | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = !!idea;
  const firstStageId = columns[0]?.stage.id ?? "";

  const [title, setTitle] = useState(idea?.title ?? "");
  const [description, setDescription] = useState(idea?.description ?? "");
  const [pipelineStageId, setPipelineStageId] = useState(firstStageId);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    setError(null);

    let result: { ok: true; data: unknown } | { ok: false; error: string };
    if (isEdit && idea) {
      result = await updateIdeaAction({
        id: idea.id,
        title: title.trim(),
        description: description.trim() || null,
      });
    } else {
      result = await createIdeaAction({
        boardId,
        title: title.trim(),
        description: description.trim() || undefined,
        pipelineStageId: pipelineStageId || undefined,
      });
    }

    setSaving(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onSaved();
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-lg bg-background p-6 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="mb-4 text-lg font-semibold">
          {isEdit ? "Editar ideia" : "Nova ideia"}
        </h2>

        {error && (
          <p
            role="alert"
            className="mb-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {error}
          </p>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="idea-title">Título</Label>
            <Input
              id="idea-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="idea-desc">Descrição</Label>
            <Textarea
              id="idea-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          {!isEdit && (
            <div className="space-y-1">
              <Label htmlFor="idea-stage">Estágio inicial</Label>
              <Select
                id="idea-stage"
                value={pipelineStageId}
                onChange={(e) => setPipelineStageId(e.target.value)}
              >
                {columns.map((c) => (
                  <option key={c.stage.id} value={c.stage.id}>
                    {c.stage.name}
                  </option>
                ))}
              </Select>
            </div>
          )}
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

/**
 * Configuração NextAuth (JWT strategy). O login é por email/senha
 * (bcrypt). No callback jwt buscamos o primeiro membership do usuário
 * para popular role + organizationId/Slug na sessão — toda query do
 * app filtra por organizationId da sessão (isolamento multi-tenant).
 *
 * (Fase 3: trocar "primeiro membership" por seleção de organização
 * ativa quando um usuário pertence a mais de uma org.)
 */
export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Credenciais",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        const email = credentials?.email?.trim().toLowerCase();
        const password = credentials?.password;
        if (!email || !password) return null;
        const user = await db.user.findUnique({ where: { email } });
        if (!user || !user.passwordHash) return null;
        const ok = await bcrypt.compare(password, user.passwordHash);
        if (!ok) return null;
        return { id: user.id, email: user.email, name: user.name };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user?.id) token.id = user.id;
      if (token.id) {
        const membership = await db.organizationMember.findFirst({
          where: { userId: token.id },
          include: { organization: { select: { slug: true } } },
        });
        if (membership) {
          token.role = membership.role;
          token.organizationId = membership.organizationId;
          token.organizationSlug = membership.organization.slug;
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = (token.id as string) ?? "";
        session.user.role = token.role as any;
        session.user.organizationId = (token.organizationId as string) ?? "";
        session.user.organizationSlug = (token.organizationSlug as string) ?? "";
      }
      return session;
    },
  },
};

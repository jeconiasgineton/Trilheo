/**
 * Calcula os updates de `order` a partir de uma lista de ids já
 * na ordem desejada. Usado por qualquer entidade ordenável
 * (stages de pipeline, lists, tasks dentro de uma lista...).
 *
 * Função pura — testável sem banco. O caller aplica os updates
 * em transação (ver innovation/service.ts reorderStages).
 */
export function computeOrderUpdates(
  orderedIds: string[],
): { id: string; order: number }[] {
  return orderedIds.map((id, order) => ({ id, order }));
}

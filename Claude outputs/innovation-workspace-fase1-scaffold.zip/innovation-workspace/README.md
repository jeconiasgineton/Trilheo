# Innovation Workspace

> Nome comercial em avaliação: **Trilheo** (domínio e pré-busca INPI já verificados — ok).

SaaS B2B que une Inovação, Melhoria Contínua, Projetos, Business Case, Gestão de Indicadores, Knowledge Management e IA (Innovation Copilot) em um único workspace.

## Status

**Fase 1 — Fundação: schema em revisão.**

- [x] Estrutura de pastas criada (`/app`, `/lib/modules/*`, `/prisma`)
- [x] `prisma/schema.prisma` completo, aguardando aprovação
- [ ] Módulo auth/permissões
- [ ] Módulo workspace/space/folder/list
- [ ] Módulo task
- [ ] Kanban/Lista
- [ ] Comentários/anexos
- [ ] Seed script

## Stack

Next.js 14 (App Router) + TypeScript · Prisma + PostgreSQL · Tailwind + shadcn/ui · NextAuth (Auth.js) · dnd-kit · Vitest

## Como rodar (depois que o schema for aprovado e os módulos implementados)

```bash
npm install
cp .env.example .env   # preencha DATABASE_URL e NEXTAUTH_SECRET
npm run prisma:migrate
npm run prisma:seed
npm run dev
```
